package prog6112eaq32019;

/**
 *
 * @author lindelo Desiree Nkosi
 */
public class PROG6112EaQ32019 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
